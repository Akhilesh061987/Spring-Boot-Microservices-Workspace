package in.ashokit.beans;

public class AppSecurity {

	public AppSecurity(String algorithm) {
		System.out.println("AppSecurity :: Constructor");
	}
}
