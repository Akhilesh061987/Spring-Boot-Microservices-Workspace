package in.ashokit.beans;

import org.springframework.stereotype.Component;

@Component
public class PwdUtils {
	
	public PwdUtils() {
		System.out.println("PwdUtils :: Constructor");
	}
}
