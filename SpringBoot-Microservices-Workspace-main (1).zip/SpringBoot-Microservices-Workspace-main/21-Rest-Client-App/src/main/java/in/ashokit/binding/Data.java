package in.ashokit.binding;

@lombok.Data
public class Data {

	private String color;
	private String capacity;
}
