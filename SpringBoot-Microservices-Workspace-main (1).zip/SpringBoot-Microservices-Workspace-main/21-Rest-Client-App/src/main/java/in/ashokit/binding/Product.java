package in.ashokit.binding;

@lombok.Data
public class Product {

	private String id;
	private String name;
	private Data data;
}
