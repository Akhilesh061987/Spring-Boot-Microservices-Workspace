package in.ashokit.binding;

@lombok.Data
public class Product {

	private Data data;
	private String name;
	private Integer id;
	
}
