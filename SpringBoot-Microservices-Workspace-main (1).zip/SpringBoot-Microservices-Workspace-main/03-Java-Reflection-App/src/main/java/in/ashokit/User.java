package in.ashokit;

public class User {

	private int age = 0;

	public void printAge() {
		System.out.println("Age :: " + age);
	}
}
