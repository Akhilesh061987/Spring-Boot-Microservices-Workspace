package in.ashokit.dto;

import lombok.Data;

@Data
public class User {

	private String uname;
	private String email;
	private Long phno;
}
