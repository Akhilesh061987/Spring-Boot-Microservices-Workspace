package in.ashokit.dao;

public interface IUserDao {
	
	public String getName(int id);

}
