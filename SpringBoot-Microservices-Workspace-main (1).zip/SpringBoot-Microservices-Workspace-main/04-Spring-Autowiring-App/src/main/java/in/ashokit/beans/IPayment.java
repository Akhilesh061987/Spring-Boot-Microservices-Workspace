package in.ashokit.beans;

public interface IPayment {
	
	public boolean doPayment(double amt);

}
